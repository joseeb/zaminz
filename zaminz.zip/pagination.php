<ul class="pagination">
	
	<?php zaminz_numeric_posts_nav(); ?>

		
</ul>
